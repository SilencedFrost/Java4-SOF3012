package com;

import com.security.PasswordHasher;
import com.service.UserService;

import java.util.logging.Logger;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    String string = "";

    public static void main(String[] args) {
    }
}
