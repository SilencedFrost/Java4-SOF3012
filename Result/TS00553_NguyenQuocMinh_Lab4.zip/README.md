## Things of note before running the program:
1. Create database.properties in src/main/resources/ according to the syntax of database.proprties.example file
2. Use the project build script, to run webApp use ./gradlew appRun, to run Main class use ./gradlew -PmainClass=Main run
3. App was written by Nguyen Quoc Minh

## Tech stack:
1. Temurin jdk21
2. gradle kotlin
3. Tomcat10
4. gretty 4.1.6
5. MSSQL
6. BS5
7. JSTL
